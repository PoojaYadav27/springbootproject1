package net.javaguides.lschoolmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import net.javaguides.lschoolmanagement.exeception.ResourceNotFoundException;
import net.javaguides.lschoolmanagement.repository.StaffRepostiory;
import net.javaguides.schoolmanagement.entity.staffmember;

@RestController
@RequestMapping("/api/staffmember")
public class StaffController {
	@Autowired
	private StaffRepostiory staffRepository;
	@GetMapping
	//get all staff member
	public List<staffmember> getAllstaffmember() {
		return this.staffRepository.findAll();
	}
	@GetMapping("/{id}")
	//get staff member by id
	public staffmember getstaffmemberId(@PathVariable (value = "id") long StaffmemberId) {
		return this.staffRepository.findById(StaffmemberId).orElseThrow(()->new ResourceNotFoundException("staff member not found with id:" + StaffmemberId));
	}

	
	//create staff member
	@PostMapping
	public  staffmember createstaffmember(@RequestBody staffmember Staffmember) {
		
		return this.staffRepository.save(Staffmember);
	}
	//update staff member
	
	@PutMapping("/{id}")
	public staffmember updatestaffmember(@RequestBody staffmember Staffmember,@PathVariable("id") long StaffmemberId) {
		staffmember existingstaffmember =  this.staffRepository.findById(StaffmemberId)
			.orElseThrow(()->new ResourceNotFoundException("user not found with id:" + StaffmemberId));
	existingstaffmember.setFirstName(Staffmember.getFirstName());
	existingstaffmember.setLastName(Staffmember.getLastName());
	existingstaffmember.setEmail(Staffmember.getEmail());
	existingstaffmember.setPhonenumber(Staffmember.getPhonenumber());
	return this.staffRepository.save(existingstaffmember);
	}
	//delete staff member
	@DeleteMapping("/{id}")
	public ResponseEntity<staffmember> deletestaffmember(@PathVariable ("id")long StaffmemberId){
		staffmember existingstaffmember =  this.staffRepository.findById(StaffmemberId)
				.orElseThrow(()->new ResourceNotFoundException("user not found with id:" + StaffmemberId));
		this.staffRepository.delete(existingstaffmember);
		return ResponseEntity.ok().build();
		
		
	}
}
