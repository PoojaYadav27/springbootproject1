package net.javaguides.lschoolmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.javaguides.schoolmanagement.entity.staffmember;

public interface StaffRepostiory extends JpaRepository<staffmember,Long>{
	
}
